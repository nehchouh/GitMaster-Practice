package com.app.accountinformation.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.accountinformation.SimpleRpcProducerRabbitApplication;
import com.app.accountinformation.model.Account;

@Service
public class AccountInformationServiceImpl{

	@PersistenceContext
	EntityManager manager;
	
	@Autowired
	SimpleRpcProducerRabbitApplication producer;
	
	
	
	public List<Account> getAccounts(Boolean transferIn, Boolean transferOut,Integer page) {

        System.out.println("In The Service Class");
        StringBuffer sb = new StringBuffer();
        sb.append(" select AccountDescriptorId,AccountId,AccountType,DisplayName,TransferIn,TransferOut,Status, ");
        sb.append(" Nickname,LineOfBusiness,AccountNumber,Currency,InterestRate,InterestRateType,Description,ParentAccountId ");
        sb.append(" from accountdescriptor as ad ");
        sb.append(" inner join  account as ac on  ad.AccountDescriptorId = ac.AccDescriptorId ");
        sb.append(" where ac.TransferIn=0 and ac.TransferOut=0 ");
       
        Query q1= manager.createNativeQuery(sb.toString(),Account.class );
       
        List<Account> accountList =q1.getResultList();
        List<Account> accounts = accountList.subList(page-1, page+1);
        System.out.println(accountList.get(0));
        
       
        producer.sendMessage(accounts);
        
		return accounts ;
	}
	
	

}
