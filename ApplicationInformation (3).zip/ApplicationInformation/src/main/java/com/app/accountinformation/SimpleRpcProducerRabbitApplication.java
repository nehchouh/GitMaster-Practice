package com.app.accountinformation;


import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.app.accountinformation.model.Account;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@EnableScheduling
@SpringBootApplication
public class SimpleRpcProducerRabbitApplication {

    private final RabbitTemplate template;


    @Autowired
    public SimpleRpcProducerRabbitApplication(RabbitTemplate template) {
        this.template = template;
    }

   
    public void sendMessage(List<Account> accounts) {
       
        this.template.convertAndSend("AccountQueue", accounts.toString());
    }

    @Bean
    public Queue queue() {
        return new Queue("AccountQueue", false);
    }
}
