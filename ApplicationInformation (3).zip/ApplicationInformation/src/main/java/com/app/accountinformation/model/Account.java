
package com.app.accountinformation.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name="account")
public class Account
    extends AccountDescriptor
    implements Serializable
{

    final static long serialVersionUID = -6043305958167914703L;
    /**
     * Parent Account Id is the identity of the parent                      account. This is used to group accounts.
     * 
     */
 /*  
    @Column(name="AccountMasterId")
    private String accountMasterId;*/
    
    
    @Column(name="ParentAccountId")
    private String parentAccountId;
    /**
     * This to display name for the account.
     * 
     */
  /*  @Column(name="AccDescriptorId")
    private String accDescriptorId;
    */
    @Column(name="Nickname")
    private String nickName;
    /**
     * Currency for particular account.
     * 
     */
    @Column(name="Currency")
    private String currency;
    /**
     * The line of business, such as consumer, consumer                     joint, small business, corporate, etc.
     * 
     */
    @Column(name="LineOfBusiness")
    private String lineOfBusiness;
    /**
     * End user�s handle for account at owning                              institution.
     * 
     */
    @Column(name="AccountNumber")
    private String accountNumber;
    /**
     * Interest Rate of Account
     * 
     */
    @Column(name="InterestRate")
    private Double interestRate;
    /**
     * Account is eligible for incoming transfers
     * 
     */
    @Column(name="TransferIn")
    private Boolean transferIn;
    /**
     * Account is eligible for outgoing transfers
     * 
     */
    @Column(name="TransferOut")
    private Boolean transferOut;
    /**
     * Interest rate type is enum which has FIXED or                        VARIABLE
     * 
     */
    @Column(name="InterestRateType")
    @Enumerated(EnumType.STRING)
    private InterestRateType interestRateType;

    /**
     * Creates a new Account.
     * 
     */
    public Account() {
        super();
    }

    /**
     * Creates a new Account.
     * 
     */
    public Account(String accountId, AccountType accountType, String displayName, String description, Status status, String parentAccountId, String nickName, String currency, String lineOfBusiness, String accountNumber, Double interestRate, Boolean transferIn, Boolean transferOut, InterestRateType interestRateType) {
        super(accountId, accountType, displayName, description, status);
        this.parentAccountId = parentAccountId;
        this.nickName = nickName;
        this.currency = currency;
        this.lineOfBusiness = lineOfBusiness;
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
        this.transferIn = transferIn;
        this.transferOut = transferOut;
        this.interestRateType = interestRateType;
    }

    /**
     * Returns the parentAccountId.
     * 
     * @return
     *     parentAccountId
     */
    public String getParentAccountId() {
        return parentAccountId;
    }

    /**
     * Set the parentAccountId.
     * 
     * @param parentAccountId
     *     the new parentAccountId
     */
    public void setParentAccountId(String parentAccountId) {
        this.parentAccountId = parentAccountId;
    }

    /**
     * Returns the nickName.
     * 
     * @return
     *     nickName
     */
    public String getNickName() {
        return nickName;
    }

    /**
     * Set the nickName.
     * 
     * @param nickName
     *     the new nickName
     */
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    /**
     * Returns the currency.
     * 
     * @return
     *     currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Set the currency.
     * 
     * @param currency
     *     the new currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * Returns the lineOfBusiness.
     * 
     * @return
     *     lineOfBusiness
     */
    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    /**
     * Set the lineOfBusiness.
     * 
     * @param lineOfBusiness
     *     the new lineOfBusiness
     */
    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Set the accountNumber.
     * 
     * @param accountNumber
     *     the new accountNumber
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    public Double getInterestRate() {
        return interestRate;
    }

    /**
     * Set the interestRate.
     * 
     * @param interestRate
     *     the new interestRate
     */
    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    /**
     * Returns the transferIn.
     * 
     * @return
     *     transferIn
     */
    public Boolean getTransferIn() {
        return transferIn;
    }

    /**
     * Set the transferIn.
     * 
     * @param transferIn
     *     the new transferIn
     */
    public void setTransferIn(Boolean transferIn) {
        this.transferIn = transferIn;
    }

    /**
     * Returns the transferOut.
     * 
     * @return
     *     transferOut
     */
    public Boolean getTransferOut() {
        return transferOut;
    }

    /**
     * Set the transferOut.
     * 
     * @param transferOut
     *     the new transferOut
     */
    public void setTransferOut(Boolean transferOut) {
        this.transferOut = transferOut;
    }

    /**
     * Returns the interestRateType.
     * 
     * @return
     *     interestRateType
     */
    public InterestRateType getInterestRateType() {
        return interestRateType;
    }

    /**
     * Set the interestRateType.
     * 
     * @param interestRateType
     *     the new interestRateType
     */
    public void setInterestRateType(InterestRateType interestRateType) {
        this.interestRateType = interestRateType;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(parentAccountId).append(nickName).append(currency).append(lineOfBusiness).append(accountNumber).append(interestRate).append(transferIn).append(transferOut).append(interestRateType).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Account otherObject = ((Account) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(parentAccountId, otherObject.parentAccountId).append(nickName, otherObject.nickName).append(currency, otherObject.currency).append(lineOfBusiness, otherObject.lineOfBusiness).append(accountNumber, otherObject.accountNumber).append(interestRate, otherObject.interestRate).append(transferIn, otherObject.transferIn).append(transferOut, otherObject.transferOut).append(interestRateType, otherObject.interestRateType).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("parentAccountId", parentAccountId).append("nickName", nickName).append("currency", currency).append("lineOfBusiness", lineOfBusiness).append("accountNumber", accountNumber).append("interestRate", interestRate).append("transferIn", transferIn).append("transferOut", transferOut).append("interestRateType", interestRateType).toString();
    }

}
