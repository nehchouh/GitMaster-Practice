
package com.app.accountinformation;

import com.app.accountinformation.model.Account;
import com.app.accountinformation.service.AccountInformationService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/accounts", produces = "application/json")
@Validated
@EnableWebSecurity
public class AccountController extends WebSecurityConfigurerAdapter {

	@Autowired
	AccountInformationService accountservice;

	@Autowired
	protected void configureUser(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("neha").password("{noop}neha@121").roles("USER").and().withUser("admin")
				.password("{noop}password").roles("ADMIN");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers("/api/accounts/pagination").access("hasRole('ADMIN')").and().formLogin();

	}

	@GetMapping(value = "/pagination")
	public ResponseEntity<?> getAccounts(@RequestParam Integer page,
			@RequestHeader(name = "Accept", defaultValue = "application/json", required = false) String accept) throws Exception {
		System.out.println("In The Controller");
		try{
			return accountservice.getAccounts(page);
		}catch(BadRequestException ex){
			return new CustomExceptionHandler().badRequest(ex);
		}
		
	}

}
