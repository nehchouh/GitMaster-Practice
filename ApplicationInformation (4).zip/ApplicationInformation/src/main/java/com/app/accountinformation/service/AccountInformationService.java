package com.app.accountinformation.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.app.accountinformation.model.Account;

public interface AccountInformationService {

	public ResponseEntity<?> getAccounts(Integer page) throws Exception;
}
