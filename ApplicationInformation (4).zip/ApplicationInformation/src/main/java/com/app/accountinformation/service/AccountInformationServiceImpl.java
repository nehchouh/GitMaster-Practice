package com.app.accountinformation.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.app.accountinformation.SimpleRpcProducerRabbitApplication;
import com.app.accountinformation.model.Account;
import com.app.accountinformation.repository.*;

@Service
public class AccountInformationServiceImpl<AccountInformationRespository> implements AccountInformationService {

	@Autowired
	private AccountInformationRepository accountInformationRepository;
	
	@Autowired
	private SimpleRpcProducerRabbitApplication producer;

	public ResponseEntity<?> getAccounts(Integer page) throws Exception{
		
		
		List<Account> accountList = accountInformationRepository.getAccountDetails();
		List<Account> accounts;
		System.out.println(accountList.size());
		
		int startIndex = page * 2 - 2, lastIndex = page * 2;
		if (lastIndex == accountList.size() + 1) {
			accounts = accountList.subList(startIndex, lastIndex - 1);
		} else if (startIndex < 0 || lastIndex > accountList.size()) {

			throw new IndexOutOfBoundsException("Please Enter Valid Page Number");
		} else {
			accounts = accountList.subList(startIndex, lastIndex);
		}
		System.out.println(accountList.get(0));
		
		producer.sendMessage(accounts);
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}

}
