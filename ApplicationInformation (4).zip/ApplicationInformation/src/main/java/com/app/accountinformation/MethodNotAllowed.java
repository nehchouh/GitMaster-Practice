package com.app.accountinformation;

public class MethodNotAllowed extends RuntimeException{

	private static final long serialVersionUID = -8514615433813307231L;

	public MethodNotAllowed(String message) {
		super(message);
	}
}
