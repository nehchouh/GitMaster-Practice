package com.example.day_two_jpa;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class DayTwoJpaApplication {
	
	@Autowired
	CustomerRepository cust;

	private static final Logger log = LoggerFactory.getLogger(DayTwoJpaApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(DayTwoJpaApplication.class, args);
	}
	
	
	@GetMapping(value="/cust")
	public ResponseEntity<List<Customer>> getCustomer(){
		return new ResponseEntity<List<Customer>>((List<Customer>) cust.findAll(), HttpStatus.OK);
		
	}
	

}
