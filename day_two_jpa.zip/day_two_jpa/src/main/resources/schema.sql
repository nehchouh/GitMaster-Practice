DROP TABLE IF EXISTS customer;

CREATE TABLE customer
(
    id varchar(36) NOT NULL,
    firstname varchar(200) NOT NULL,
    lastname varchar(500) NOT NULL,
    PRIMARY KEY (id)
);
