insert into customer(id,firstname,lastname) values('101','Neha','Chouhan');
insert into customer(id,firstname,lastname) values('102','Ram','Pawar');
insert into customer(id,firstname,lastname) values('103','Pooja','Mantri');
insert into customer(id,firstname,lastname) values('104','Kalpana','Bharati');
