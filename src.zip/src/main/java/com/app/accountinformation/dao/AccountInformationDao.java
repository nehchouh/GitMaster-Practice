package com.app.accountinformation.dao;

import com.app.accountinformation.model.Account;
import com.app.accountinformation.model.Accounts;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountInformationDao extends CrudRepository<Account,String>{

	public List<Account>getAccounts(Boolean transferIn,Boolean transferOut);
}
