
package com.app.accountinformation.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class AccountDescriptor implements Serializable
{

    final static long serialVersionUID = -6043305958167914703L;
    /**
     * Account id for accessing accounts,this identity                      must be unique.
     * 
     */
    private String accountId;
    /**
     * Account type which are enum.
     * 
     */
    private AccountType accountType;
    /**
     * Account identity to display to customer.
     * 
     */
    private String displayName;
    /**
     * Description of account.
     * 
     */
    private String description;
    /**
     * Status for accounts.
     * 
     */
    private Status status;

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor() {
        super();
    }

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor(String accountId, AccountType accountType, String displayName, String description, Status status) {
        super();
        this.accountId = accountId;
        this.accountType = accountType;
        this.displayName = displayName;
        this.description = description;
        this.status = status;
    }

    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Set the accountId.
     * 
     * @param accountId
     *     the new accountId
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * Returns the accountType.
     * 
     * @return
     *     accountType
     */
    public AccountType getAccountType() {
        return accountType;
    }

    /**
     * Set the accountType.
     * 
     * @param accountType
     *     the new accountType
     */
    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    /**
     * Returns the displayName.
     * 
     * @return
     *     displayName
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Set the displayName.
     * 
     * @param displayName
     *     the new displayName
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Returns the description.
     * 
     * @return
     *     description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set the description.
     * 
     * @param description
     *     the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
    public Status getStatus() {
        return status;
    }

    /**
     * Set the status.
     * 
     * @param status
     *     the new status
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(accountId).append(accountType).append(displayName).append(description).append(status).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        AccountDescriptor otherObject = ((AccountDescriptor) other);
        return new EqualsBuilder().append(accountId, otherObject.accountId).append(accountType, otherObject.accountType).append(displayName, otherObject.displayName).append(description, otherObject.description).append(status, otherObject.status).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("accountId", accountId).append("accountType", accountType).append("displayName", displayName).append("description", description).append("status", status).toString();
    }

}
