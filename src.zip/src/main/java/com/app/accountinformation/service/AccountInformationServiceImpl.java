package com.app.accountinformation.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.app.accountinformation.model.Account;

@Service
public class AccountInformationServiceImpl implements AccountInformationService{

	@PersistenceContext
	EntityManager manager;
	
	@Override
	public Account getAccounts(Boolean transferIn, Boolean transferOut) {

        System.out.println("In the service class");
        StringBuffer sb = new StringBuffer();
        /*sb.append("select accountId,accountType,DisplayName,TransferIn,TransferOut,Status,");
        sb.append("Nickname,LineOfBusiness,AccountNumber,Currency,InterestRate,InterestRateType");
        sb.append("from accountdescriptor as ad");
        sb.append("inner join  account as ac on  ad.AccountDescriptorId = ac.AccDescriptorId");
        sb.append("where ac.TransferIn=0 and ac.TransferOut=0;");*/
        sb.append("select * from Account");
        
        Query q1= manager.createNativeQuery(sb.toString(), Account.class);
        System.out.println(q1.getFirstResult());
        System.out.println(q1.toString());
		return null ;
	}

}
