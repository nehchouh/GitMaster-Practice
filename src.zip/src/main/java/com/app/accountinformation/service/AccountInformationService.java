package com.app.accountinformation.service;

import java.util.List;

import com.app.accountinformation.model.Account;

public interface AccountInformationService {

	public Account getAccounts(Boolean transferIn,Boolean transferOut);
}
