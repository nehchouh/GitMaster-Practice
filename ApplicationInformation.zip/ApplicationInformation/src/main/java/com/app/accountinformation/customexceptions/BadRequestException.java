package com.app.accountinformation.customexceptions;


public class BadRequestException extends RuntimeException{

	
	private static final long serialVersionUID = -8514615433813307231L;

	public BadRequestException(String message) {
		super(message);
	}
}
