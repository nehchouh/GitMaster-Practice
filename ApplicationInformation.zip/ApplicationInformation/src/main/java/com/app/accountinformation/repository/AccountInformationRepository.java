package com.app.accountinformation.repository;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.app.accountinformation.model.Account;

@Repository
public interface AccountInformationRepository extends CrudRepository<Account, String> {

	@Query(value = " select AccountDescriptorId,AccountId,AccountType,DisplayName,TransferIn,TransferOut,Status,CustomerId,"
			+ "Nickname,LineOfBusiness,AccountNumber,Currency,InterestRate,InterestRateType,Description,ParentAccountId "
			+ " from accountdescriptor as ad "
			+ " inner join  account as ac on  ad.AccountDescriptorId = ac.AccDescriptorId "
			+ " where ac.TransferIn=false and ac.TransferOut=false", nativeQuery = true)
	public List<Account> getAccountDetails();
}
