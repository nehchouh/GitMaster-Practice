package com.app.accountinformation;

import java.lang.reflect.Constructor;


/**
* @author a622828
*
*/
public class ResponseData {

	

	private Object data;
	private String message;

	/**
	 * {@link Constructor}{@link ResponseDto}
	 */
	public ResponseData() {
		System.out.println("Inside response data class");
	}

	/**
	 * @return the status
	 */
	/**
	 * @return the data
	 */
	public Object getData() {
		return data;
	}

	/**
	 * @param data
	 *            the data to set
	 */
	public void setData(Object data) {
		this.data = data;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 *            the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @param msg
	 * @param obj
	 * @return ResponseDto
	 */
	public static ResponseData successResponse(String msg, Object obj) {
		ResponseData sucess = new ResponseData();
		sucess.setMessage(msg);
		sucess.setData(obj);
		return sucess;
	}

	/**
	 * @param msg
	 * @param obj
	 * @return ResponseDto
	 */
	public static ResponseData failureResponse(String msg, Object obj) {
		ResponseData failure = new ResponseData();
		failure.setMessage(msg);
		failure.setData(obj);
		return failure;
	}
}

