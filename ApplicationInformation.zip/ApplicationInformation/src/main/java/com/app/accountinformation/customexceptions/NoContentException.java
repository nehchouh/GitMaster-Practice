package com.app.accountinformation.customexceptions;

public class NoContentException extends RuntimeException{

	
	private static final long serialVersionUID = -8514615433813307231L;

	public NoContentException(String message) {
		super(message);
	}
}
