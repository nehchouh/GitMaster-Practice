
package com.app.accountinformation;

import com.app.accountinformation.customexceptions.BadRequestException;
import com.app.accountinformation.customexceptions.InternalServerError;
/*import com.app.accountinformation.customexceptions.MethodNotAllowed;*/
import com.app.accountinformation.customexceptions.NoContentException;
import com.app.accountinformation.model.Account;
import com.app.accountinformation.service.AccountInformationService;
import com.app.accountinformation.service.BankCatalogClient;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.logging.log4j.LoggingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/accounts", produces = "application/json")
@Validated
public class AccountController {

	@Autowired
	AccountInformationService accountservice;
	final static Logger logger = Logger.getLogger(AccountController.class);

	@Autowired
	BankCatalogClient bankCatalogClient;
	
	@GetMapping(value = "/pagination")
	public ResponseEntity<?> getAccounts(@RequestParam Integer page,
			@RequestHeader(name = "Accept", defaultValue = "application/json", required = false) String accept) {
		logger.info("This Is information meessage");
		System.out.println("In The Controller");
		try {
			
			List<Account> account ;
			account = accountservice.getAccounts(page);
			bankCatalogClient.getBankById(account.get(0).getCustomerId());
			System.out.println("Output of account"+account);
			
			return new ResponseEntity <List<Account>>(account, HttpStatus.OK); 
			/* return new ResponseEntity<List<Account>>(accountservice.getAccounts(page),HttpStatus.OK); */
		} catch (Exception ex) {
			return new CustomExceptionHandler().internalError(ex); 
			
		}	
	}
}
		
			 /*try{ 
				 return new ResponseEntity<List<Account>>(accountservice.getAccounts(page),HttpStatus.OK); 
				 }catch(Exception ex){
					 return new CustomExceptionHandler().internalError(ex); 
					 }	 
	}*/
	

