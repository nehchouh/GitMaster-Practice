
package com.app.accountinformation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.accountinformation.customexception.BadRequestException;
import com.app.accountinformation.customexception.MethodNotAllowed;
import com.app.accountinformation.customexception.NoContentException;
import com.app.accountinformation.service.AccountInformationService;

@RestController
@RequestMapping(value = "/api/accounts", produces = "application/json")
@Validated

public class AccountController{

	@Autowired
	AccountInformationService accountservice;

	
	@GetMapping(value = "/pagination")
	public ResponseEntity<?> getAccounts(@RequestParam Integer page,
			@RequestHeader(name = "Accept", defaultValue = "application/json", required = false) String accept) throws Exception {
		System.out.println("In The Controller");
		try{
			return accountservice.getAccounts(page);
		}catch(BadRequestException badrequestexception){
			return new CustomExceptionHandler().badRequest(badrequestexception);
		}catch(MethodNotAllowed ex) {
			return new CustomExceptionHandler().methodNotAllowed(ex);
		}catch(NoContentException ex) {
			return new CustomExceptionHandler().noContent(ex);
		}catch(Exception ex) {
			return new CustomExceptionHandler().internalError(ex);
		}
		
	}

}
