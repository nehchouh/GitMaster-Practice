package com.app.accountinformation.service;


import java.util.List;

import com.app.accountinformation.model.Account;

public interface AccountInformationService {

	public List<Account> getAccounts(Integer page) throws Exception;
}
