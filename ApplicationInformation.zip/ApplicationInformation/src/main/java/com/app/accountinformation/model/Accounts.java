
package com.app.accountinformation.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Accounts implements Serializable {

	final static long serialVersionUID = -6071398185736446768L;
	/**
	 * Total number of results in this collection across all pages
	 * 
	 */
	private Double total;
	/**
	 * Total number of pages
	 * 
	 */
	private Double totalPages;
	/**
	 * Current page number
	 * 
	 */
	private Double page;
	/**
	 * An array of accounts.
	 * 
	 */
	private List<Account> account = new ArrayList<Account>();

	/**
	 * Creates a new Accounts.
	 * 
	 */
	public Accounts() {
		super();
	}

	/**
	 * Creates a new Accounts.
	 * 
	 */
	public Accounts(Double total, Double totalPages, Double page, List<Account> account) {
		super();
		this.total = total;
		this.totalPages = totalPages;
		this.page = page;
		this.account = account;
	}

	/**
	 * Returns the total.
	 * 
	 * @return total
	 */
	public Double getTotal() {
		return total;
	}

	/**
	 * Set the total.
	 * 
	 * @param total
	 *            the new total
	 */
	public void setTotal(Double total) {
		this.total = total;
	}

	/**
	 * Returns the totalPages.
	 * 
	 * @return totalPages
	 */
	public Double getTotalPages() {
		return totalPages;
	}

	/**
	 * Set the totalPages.
	 * 
	 * @param totalPages
	 *            the new totalPages
	 */
	public void setTotalPages(Double totalPages) {
		this.totalPages = totalPages;
	}

	/**
	 * Returns the page.
	 * 
	 * @return page
	 */
	public Double getPage() {
		return page;
	}

	/**
	 * Set the page.
	 * 
	 * @param page
	 *            the new page
	 */
	public void setPage(Double page) {
		this.page = page;
	}

	/**
	 * Returns the account.
	 * 
	 * @return account
	 */
	public List<Account> getAccount() {
		return account;
	}

	/**
	 * Set the account.
	 * 
	 * @param account
	 *            the new account
	 */
	public void setAccount(List<Account> account) {
		this.account = account;
	}

	public int hashCode() {
		return new HashCodeBuilder().append(total).append(totalPages).append(page).append(account).toHashCode();
	}

	public boolean equals(Object other) {
		if (other == null) {
			return false;
		}
		if (other == this) {
			return true;
		}
		if (this.getClass() != other.getClass()) {
			return false;
		}
		Accounts otherObject = ((Accounts) other);
		return new EqualsBuilder().append(total, otherObject.total).append(totalPages, otherObject.totalPages)
				.append(page, otherObject.page).append(account, otherObject.account).isEquals();
	}

	public String toString() {
		return new ToStringBuilder(this).append("total", total).append("totalPages", totalPages).append("page", page)
				.append("account", account).toString();
	}

}
