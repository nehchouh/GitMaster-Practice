package com.app.accountinformation.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.app.accountinformation.AccountController;
import com.app.accountinformation.SimpleRpcProducerRabbitApplication;
/*import com.app.accountinformation.SimpleRpcProducerRabbitApplication;*/
import com.app.accountinformation.customexceptions.BadRequestException;
import com.app.accountinformation.customexceptions.NoContentException;
import com.app.accountinformation.model.Account;
import com.app.accountinformation.model.Accounts;
import com.app.accountinformation.repository.*;

@Service
public class AccountInformationServiceImpl<AccountInformationRespository> implements AccountInformationService {

	@Autowired
	private AccountInformationRepository accountInformationRepository;
	
	@Autowired
	private SimpleRpcProducerRabbitApplication producer;
	
	final static Logger logger = Logger.getLogger(AccountController.class);

	public List<Account> getAccounts(Integer page) throws Exception{
		
		
		List<Account> accountList = accountInformationRepository.getAccountDetails();
		List<Account> accounts;
		logger.info("This is information");
		int p;
		
		
		try{
			p = Integer.parseInt(page.toString());
		}catch(BadRequestException ex){
			throw new BadRequestException("Enter Valid Page Number");
		}
		int startIndex = page * 2 - 2, lastIndex = page * 2;
		try{
		if (lastIndex == accountList.size() + 1) {
			accounts = accountList.subList(startIndex, lastIndex - 1);
		} else {
			accounts = accountList.subList(startIndex, lastIndex);
		}
		}catch(IndexOutOfBoundsException ex){
			throw new NoContentException("There is No Data on this page");
		}
		System.out.println(accountList.get(0));
		
	    producer.sendMessage(accounts);
		return accounts;
	}

}
