package com.app.accountinformation.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.app.accountinformation.customexception.BadRequestException;
import com.app.accountinformation.customexception.NoContentException;
import com.app.accountinformation.model.Account;
import com.app.accountinformation.repository.*;

@Service
public class AccountInformationServiceImpl<AccountInformationRespository> implements AccountInformationService {

	@Autowired
	private AccountInformationRepository accountInformationRepository;
	
	/*@Autowired
	private SimpleRpcProducerRabbitApplication producer;*/

	public ResponseEntity<?> getAccounts(Integer page) throws Exception{
		
		
		List<Account> accountList = accountInformationRepository.getAccountDetails();
		List<Account> accounts;
		System.out.println(accountList.size());
		int p;
		try {
		p = Integer.parseInt(page.toString());
		}catch(BadRequestException ex)
		{
			throw new BadRequestException("Please Enter valid Request Parameter");
		}
		int startIndex = page * 2 - 2, lastIndex = page * 2;
		try {
		if (accountList!=null && lastIndex == accountList.size() + 1) {
			accounts = accountList.subList(startIndex, lastIndex - 1);
		} else {
			accounts = accountList.subList(startIndex, lastIndex);
		}
		
		}catch(IndexOutOfBoundsException index) {
			
			throw new NoContentException("There is no data on this page");
			
		}
		System.out.println(accountList.get(0));
		
		/*producer.sendMessage(accounts);*/
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}

}
