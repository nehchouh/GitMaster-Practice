package com.app.accountinformation;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.app.accountinformation.customexceptions.BadRequestException;
import com.app.accountinformation.customexceptions.InternalServerError;
/*import com.app.accountinformation.customexceptions.MethodNotAllowed;*/
import com.app.accountinformation.customexceptions.NoContentException;
import com.app.accountinformation.model.Error;

@ControllerAdvice
@RestController
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(value = BadRequestException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ResponseEntity<Error> badRequest(BadRequestException ex) {
       System.out.println("In bad request");
		return new ResponseEntity<Error>(new Error("400", ex.getMessage()), HttpStatus.BAD_REQUEST);

	}

	@ExceptionHandler(value = InternalServerError.class)
	public ResponseEntity<Error> internalError(Exception ex) {
		return new ResponseEntity<Error>(new Error("500", ex.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(value = NoContentException.class)
	public ResponseEntity<Error> noContent(NoContentException ex) {
		return new ResponseEntity<Error>(new Error("204", ex.getMessage()), HttpStatus.NO_CONTENT);
	}

	@Override
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		// TODO Auto-generated method stub
		return new ResponseEntity<Object>(new Error("405", ex.getMessage()), HttpStatus.METHOD_NOT_ALLOWED);
	}
	
	

}
