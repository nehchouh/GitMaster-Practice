package com.app.accountinformation;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.app.accountinformation.model.Error;
import com.app.accountinformation.customexception.BadRequestException;
import com.app.accountinformation.customexception.InternalServerError;
import com.app.accountinformation.customexception.MethodNotAllowed;
import com.app.accountinformation.customexception.NoContentException;

@ControllerAdvice
@RestController
public class CustomExceptionHandler extends ResponseEntityExceptionHandler{

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value=BadRequestException.class)
	public ResponseEntity<Error> badRequest(BadRequestException ex){
		
		return new ResponseEntity<Error>(new Error("400",ex.getMessage()),HttpStatus.BAD_REQUEST);
		
	}
		
	@ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
	@ExceptionHandler(value=MethodNotAllowed.class)
	public ResponseEntity<Error> methodNotAllowed(MethodNotAllowed ex){
		return new ResponseEntity<Error>(new Error("405",ex.getMessage()),HttpStatus.METHOD_NOT_ALLOWED);
	}
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(value=InternalServerError.class)
	public ResponseEntity<Error> internalError(Exception ex){
		return new ResponseEntity<Error>(new Error("500",ex.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ResponseStatus(HttpStatus.NO_CONTENT)
	@ExceptionHandler(value=NoContentException.class)
	public ResponseEntity<Error> noContent(NoContentException ex){
		return new ResponseEntity<Error>(new Error("204",ex.getMessage()),HttpStatus.NO_CONTENT);
	}
	
	
		
}
