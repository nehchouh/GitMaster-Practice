package com.app.accountinformation.customexceptions;

public class InternalServerError extends RuntimeException{
 
	private static final long serialVersionUID = -8514615433813307231L;

	public InternalServerError(String message) {
		super(message);
	}
}
